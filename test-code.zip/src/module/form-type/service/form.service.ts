import { Injectable } from '@nestjs/common';
import { FormRepository } from '../repository/form.repository';
import { FormFieldRepository } from '../repository/formField.repository';
import { DynamicFieldDto } from '../dto/createForm.dto';
import { FormDataDTO } from '../dto/formData.dto';
import { FormDataRepository } from '../repository/formData.repository';

import { v4 as uuid } from 'uuid';

@Injectable()
export class FormService {
    constructor(
        private formRepository: FormRepository,
        private formFieldRepository: FormFieldRepository,
        private formDataRepository: FormDataRepository,
    ) { }

    /**
     * User will provides list of fields with data type
     * i.e phone_numner : number
     * Function will add form type and and form fields.
     * @param dynamicFieldDto 
     * @returns 
     */

    async createFormAndFields(dynamicFieldDto: DynamicFieldDto) {
        const { title } = dynamicFieldDto;
        // Create a new Form
        const form = await this.formRepository.create({ title });

        for (const field of Object.keys(dynamicFieldDto)) {
            console.log(field, dynamicFieldDto[field]);
            if (field !== 'title') {
                const type = dynamicFieldDto[field];
                console.log(`Field name: ${field}, Field value: ${type}`);

                await this.formFieldRepository.create({
                    fieldName: field,
                    fieldType: type,
                    formId: form.id,
                });
            }
        }

        return { form };
    }

    async fillFormData(formTitle: string, bodyData: any) {
        const form = await this.formRepository.findByTitle(formTitle);
        if (!form) {
            throw new Error('form_title_not_found');
        }

        const uniqueId = uuid();
        form.formFields.forEach(formField => {
            const key = formField.fieldName;
            const fieldValue = bodyData[key];
            if (fieldValue) {
                
                console.log(typeof fieldValue, formField.fieldType);
                if (typeof fieldValue !== formField.fieldType) {
                    throw new Error(`FieldTypeError: Invalid value provided form field of ${formField.fieldName}.`)
                }
                const formData: FormDataDTO = { formId: form.id, formFieldId: formField.id, fieldValue, uniqueId };
                this.formDataRepository.create(formData);
            }
        });

        return true;;
    }

    /**
     * Receive title for form type and returns all form data for given title.
     * @param formTitle 
     * @param bodyData 
     */
    async findFormData(formTitle: string): Promise<any> {
        const form = await this.formRepository.findByTitle(formTitle);
        if (!form) {
            throw new Error('form_title_not_found');
        }

        const formDataRecords = await this.formDataRepository.findByFormId(form.id);
        if (!formDataRecords) {
            return [];
        }

        let result = [];
       

        return this.transformData(formDataRecords);
    }

     transformData  (input: any): any {
        const output: any = {};
    
        for (const key in input) {
            const { uniqueId, fieldValue, formField } = input[key];
            const fieldName = formField.fieldName;
    
            if (!output[uniqueId]) {
                output[uniqueId] = {};
            }
    
            output[uniqueId][fieldName] = fieldValue;
        }
    
        return output;
    };
}
