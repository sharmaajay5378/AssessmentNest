import { Column, DataType, HasMany, Model, Table } from 'sequelize-typescript';
import { FormDTO } from '../dto/form.dto';
import { FormFieldEntity } from './formField.entity';

@Table({ tableName: 'forms' })
export class FormEntity extends Model<FormDTO> {
    @Column({
        primaryKey: true,
        type: DataType.INTEGER,
        autoIncrement: true, // This makes the id auto-incrementing
    })
    id: number;

    @Column({
        allowNull: false,
        type: DataType.STRING,
    })
    title: string;

    @HasMany(() => FormFieldEntity)
    formFields: FormFieldEntity[];
}
