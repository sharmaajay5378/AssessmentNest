import { Body, Controller, Get, HttpCode, HttpStatus, Post, Query } from '@nestjs/common';
import { FormService } from '../service/form.service';
import { Response as ResponseCustom } from 'src/utils/response/response.decorator';
import { responseName } from '../response/response.constants';

@Controller()
export class FormController {
    constructor(private formService: FormService) {}

    // POST  API to create the post.
    @Post()
    @HttpCode(HttpStatus.CREATED)
    @ResponseCustom(responseName.FORM_TYPE_CREATED)
    async createForm(@Body() dynamicFieldDto: any) {
        console.log(dynamicFieldDto);
        return await this.formService.createFormAndFields(dynamicFieldDto);
    }

    // POST  API to create the post.
    @Post('fill-data')
    @HttpCode(HttpStatus.CREATED)
    @ResponseCustom(responseName.FORM_TYPE_CREATED)
    async fillForm(@Body() formDataDTO: any, @Query() query: any) {
        return await this.formService.fillFormData(query.title, formDataDTO);
    }

    // POST  API to create the post.
    @Get('get-data')
    @HttpCode(HttpStatus.CREATED)
    @ResponseCustom(responseName.FORM_TYPE_CREATED)
    async getFormData(@Query() query: any) {
        return await this.formService.findFormData(query.title);
    }
}
