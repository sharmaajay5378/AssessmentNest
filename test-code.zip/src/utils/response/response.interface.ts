export interface iResponseStatusMessage {
    statusCode: number;
    message: string;
}
